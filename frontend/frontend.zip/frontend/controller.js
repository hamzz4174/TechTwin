$(document).ready(function () {

  const hasEel = typeof eel !== "undefined";

  if (!hasEel) {
    console.warn("EEL not found – running in WEB MODE");
  }

  // SAFE expose helper
  function safeExpose(fn) {
    if (hasEel) eel.expose(fn);
  }

  // ----------------------------
  safeExpose(DisplayMessage);
  function DisplayMessage(message) {
    $(".siri-message li:first").text(message);
    $(".siri-message").textillate("start");
  }

  safeExpose(ShowHood);
  function ShowHood() {
    $("#Oval").attr("hidden", false);
    $("#SiriWave").attr("hidden", true);
  }

  safeExpose(senderText);
  function senderText(message) {
    var chatBox = document.getElementById("chat-canvas-body");
    if (message.trim() !== "") {
     chatBox.insertAdjacentHTML("beforeend", `
<div class="chat-row sender">
  <div class="chat-bubble sender-bubble">${message}</div>
</div>
`);
      chatBox.scrollTop = chatBox.scrollHeight;
    }
  }

  safeExpose(receiverText);
  function receiverText(message) {
    var chatBox = document.getElementById("chat-canvas-body");
    if (message.trim() !== "") {
      chatBox.insertAdjacentHTML("beforeend", `
<div class="chat-row receiver">
  <div class="chat-bubble receiver-bubble">${message}</div>
</div>
`);

      chatBox.scrollTop = chatBox.scrollHeight;
    }
  }

  safeExpose(hideLoader);
  function hideLoader() {
    $("#Loader").attr("hidden", true);
    $("#FaceAuth").attr("hidden", false);
  }

  safeExpose(hideFaceAuth);
  function hideFaceAuth() {
    $("#FaceAuth").attr("hidden", true);
    $("#FaceAuthSuccess").attr("hidden", false);
  }

  safeExpose(hideFaceAuthSuccess);
  function hideFaceAuthSuccess() {
    $("#FaceAuthSuccess").attr("hidden", true);
    $("#HelloGreet").attr("hidden", false);
  }

  safeExpose(hideStart);
  function hideStart() {
    $("#Start").attr("hidden", true);

    setTimeout(function () {
      $("#Oval").addClass("animate__animated animate__zoomIn");
    }, 1000);
    setTimeout(function () {
      $("#Oval").attr("hidden", false);
    }, 1000);
  }

});
