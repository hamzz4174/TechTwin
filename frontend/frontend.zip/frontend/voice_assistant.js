const API_URL = "http://localhost:5000/ask";

// === Elements ===
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const subjectSelect = document.getElementById("subjectSelect");
const pdfSelect = document.getElementById("pdfSelect");
const transcriptEl = document.getElementById("transcript");
const aiReplyEl = document.getElementById("aiReply");

// === Load Subjects ===
async function loadSubjects() {
  try {
    const res = await fetch(`${API_URL}/subjects`);
    const data = await res.json();

    if (!data.subjects?.length) {
      subjectSelect.innerHTML = `<option>No subjects found</option>`;
      return;
    }

    subjectSelect.innerHTML = data.subjects
      .map(sub => `<option value="${sub}">${sub}</option>`)
      .join("");
  } catch (err) {
    console.error("Error loading subjects:", err);
    subjectSelect.innerHTML = `<option>Error loading subjects</option>`;
  }
}
loadSubjects();

// === Load PDFs when subject changes ===
subjectSelect.addEventListener("change", async () => {
  const subject = subjectSelect.value;
  if (!subject) return;
  pdfSelect.innerHTML = "<option>Loading PDFs...</option>";

  const res = await fetch(`${API_URL}/pdfs/${encodeURIComponent(subject)}`);
  const data = await res.json();

  if (!data.pdfs?.length) {
    pdfSelect.innerHTML = `<option>No PDFs found</option>`;
    return;
  }

  pdfSelect.innerHTML = data.pdfs
    .map(pdf => `<option value="${pdf}">${pdf.replace('.pdf', '')}</option>`)
    .join("");
});

// === Speech Recognition ===
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognizer = new SpeechRecognition();
recognizer.lang = "en-IN";
recognizer.interimResults = true;
recognizer.maxAlternatives = 1;

let finalTranscript = "";

recognizer.onresult = (ev) => {
  let interim = "";
  for (let i = ev.resultIndex; i < ev.results.length; ++i) {
    const result = ev.results[i];
    if (result.isFinal) finalTranscript += result[0].transcript;
    else interim += result[0].transcript;
  }
  transcriptEl.innerText = finalTranscript + (interim ? " — " + interim : "");
};

recognizer.onerror = (e) => {
  transcriptEl.innerText = "Recognition error: " + e.message;
};

recognizer.onend = async () => {
  stopBtn.disabled = true;
  startBtn.disabled = false;
  if (finalTranscript.trim()) {
    await sendToAI(finalTranscript.trim());
    finalTranscript = "";
  }
};

// === Controls ===
startBtn.onclick = () => {
  finalTranscript = "";
  transcriptEl.innerText = "Listening...";
  recognizer.start();
  startBtn.disabled = true;
  stopBtn.disabled = false;
};
stopBtn.onclick = () => recognizer.stop();

// === Send query ===
async function sendToAI(text) {
  transcriptEl.innerText = "Analyzing your question...";
  const subject = subjectSelect.value;
  const pdf = pdfSelect.value;

  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question: text, subject, lectureId: pdf })
  });
  const data = await res.json();

  aiReplyEl.innerText = data.answer || "No answer found.";
  speakText(data.answer);
}

async function speakText(text) {
  try {
    if (!text || !text.trim()) return;

    const res = await fetch("http://127.0.0.1:5000/auth/speak", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: text.slice(0, 300) }) // limit length
    });

    if (!res.ok) throw new Error("TTS fetch failed");

    const audioBlob = await res.blob();
    const audioUrl = URL.createObjectURL(audioBlob);

    const audio = new Audio(audioUrl);
    audio.play();

  } catch (err) {
    console.error("Speak error:", err);
  }
}





