document.addEventListener("submit", e => {
  e.preventDefault();
  e.stopPropagation();
  return false;
});
$(document).ready(function () {

  // ---- SAFE EEL CHECK ----
  const hasEel = typeof eel !== "undefined";

  if (hasEel && eel.init) {
    try {
      eel.init()();
    } catch (e) {
      console.warn("EEL init skipped (web mode)");
    }
  }

  // ---- TEXT ANIMATIONS ----
  $(".text").textillate({
    loop: true,
    speed: 1500,
    sync: true,
    in: { effect: "bounceIn" },
    out: { effect: "bounceOut" },
  });

  $(".siri-message").textillate({
    loop: true,
    sync: true,
    in: { effect: "fadeInUp", sync: true },
    out: { effect: "fadeOutUp", sync: true },
  });

  

  // ---- MIC BUTTON ----
  $("#MicBtn").click(function () {
    $("#Oval").attr("hidden", true);
    $("#SiriWave").attr("hidden", false);

    if (hasEel) {
      eel.play_assistant_sound();
      eel.takeAllCommands()();
    } else {
      console.log("Mic pressed (web mode)");
    }
  });

  // ---- KEY SHORTCUT ----
  document.addEventListener("keyup", function (e) {
    if (e.key === "j" && e.metaKey) {
      $("#Oval").attr("hidden", true);
      $("#SiriWave").attr("hidden", false);

      if (hasEel) {
        eel.play_assistant_sound();
        eel.takeAllCommands()();
      }
    }
  });

  // ---- CHAT SEND ----
  function PlayAssistant(message) {
    if (!message) return;

    $("#Oval").attr("hidden", true);
    $("#SiriWave").attr("hidden", false);

    if (hasEel) {
      eel.takeAllCommands(message);
    } else {
      console.log("Web mode message:", message);
    }

    $("#chatbox").val("");
    $("#MicBtn").attr("hidden", false);
    $("#SendBtn").attr("hidden", true);
  }

  function ShowHideButton(message) {
    if (message.length === 0) {
      $("#MicBtn").attr("hidden", false);
      $("#SendBtn").attr("hidden", true);
    } else {
      $("#MicBtn").attr("hidden", true);
      $("#SendBtn").attr("hidden", false);
    }
  }

  $("#chatbox").keyup(function () {
    ShowHideButton($(this).val());
  });

  $("#SendBtn").click(function () {
    PlayAssistant($("#chatbox").val());
  });

  $("#chatbox").keypress(function (e) {
    if (e.which === 13) {
      PlayAssistant($("#chatbox").val());
    }
  });

});
